﻿using MusicLounge.Application.DTOs.Auth;
using MusicLounge.Application.Interfaces;
using MusicLounge.Domain.Entities;
using MusicLounge.Domain.Enums;

namespace MusicLounge.Application.Services;

public class AuthService
{
    private readonly IUserRepository _userRepository;
    private readonly IPasswordHasher _passwordHasher;
    private readonly IJwtTokenGenerator _jwtTokenGenerator;

    public AuthService(
        IUserRepository userRepository,
        IPasswordHasher passwordHasher,
        IJwtTokenGenerator jwtTokenGenerator)
    {
        _userRepository = userRepository;
        _passwordHasher = passwordHasher;
        _jwtTokenGenerator = jwtTokenGenerator;
    }

    public async Task<Guid> RegisterAsync(RegisterRequest request)
    {
        var email = request.Email.Trim().ToLower();

        var isEmailExists = await _userRepository.IsEmailExistsAsync(email);

        if (isEmailExists)
            throw new InvalidOperationException("Email đã được sử dụng.");

        if (request.Password.Length < 6)
            throw new InvalidOperationException("Mật khẩu phải có ít nhất 6 ký tự.");

        if (request.Role == UserRole.Admin)
            throw new InvalidOperationException("Không thể tự đăng ký tài khoản Admin.");

        var passwordHash = _passwordHasher.Hash(request.Password);

        var user = new User(
            request.FullName,
            email,
            passwordHash,
            request.Role
        );

        await _userRepository.AddAsync(user);
        await _userRepository.SaveChangesAsync();

        return user.Id;
    }

    public async Task<AuthResponse> LoginAsync(LoginRequest request)
    {
        var email = request.Email.Trim().ToLower();

        var user = await _userRepository.GetByEmailAsync(email);

        if (user == null)
            throw new UnauthorizedAccessException("Email hoặc mật khẩu không đúng.");

        if (!user.IsActive)
            throw new UnauthorizedAccessException("Tài khoản đã bị khóa.");

        var isPasswordValid = _passwordHasher.Verify(
            request.Password,
            user.PasswordHash
        );

        if (!isPasswordValid)
            throw new UnauthorizedAccessException("Email hoặc mật khẩu không đúng.");

        var accessToken = _jwtTokenGenerator.GenerateToken(user);

        return new AuthResponse
        {
            UserId = user.Id,
            FullName = user.FullName,
            Email = user.Email,
            Role = user.Role.ToString(),
            AccessToken = accessToken
        };
    }
}