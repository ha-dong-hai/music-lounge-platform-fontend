﻿using MusicLounge.Domain.Entities;

namespace MusicLounge.Application.Interfaces;

public interface IUserRepository
{
    Task<bool> IsEmailExistsAsync(string email);
    Task<User?> GetByEmailAsync(string email);
    Task AddAsync(User user);
    Task SaveChangesAsync();
}