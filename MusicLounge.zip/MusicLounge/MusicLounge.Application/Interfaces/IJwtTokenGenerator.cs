﻿using MusicLounge.Domain.Entities;

namespace MusicLounge.Application.Interfaces;

public interface IJwtTokenGenerator
{
    string GenerateToken(User user);
}