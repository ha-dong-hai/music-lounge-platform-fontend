﻿using Microsoft.EntityFrameworkCore;
using MusicLounge.Domain.Entities;
using System.Collections.Generic;

namespace MusicLounge.Infrastructure.Persistence;

public class AppDbContext : DbContext
{
    public DbSet<User> Users => Set<User>();

    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }
}