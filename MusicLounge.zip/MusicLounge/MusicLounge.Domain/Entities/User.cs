﻿using MusicLounge.Domain.Enums;

namespace MusicLounge.Domain.Entities;

public class User
{
    public Guid Id { get; private set; }
    public string FullName { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string PasswordHash { get; private set; } = string.Empty;
    public UserRole Role { get; private set; }
    public bool IsActive { get; private set; }
    public DateTime CreatedAt { get; private set; }

    private User() { }

    public User(
        string fullName,
        string email,
        string passwordHash,
        UserRole role)
    {
        if (string.IsNullOrWhiteSpace(fullName))
            throw new ArgumentException("Họ tên không được để trống.");

        if (string.IsNullOrWhiteSpace(email))
            throw new ArgumentException("Email không được để trống.");

        if (string.IsNullOrWhiteSpace(passwordHash))
            throw new ArgumentException("Mật khẩu không hợp lệ.");

        Id = Guid.NewGuid();
        FullName = fullName.Trim();
        Email = email.Trim().ToLower();
        PasswordHash = passwordHash;
        Role = role;
        IsActive = true;
        CreatedAt = DateTime.UtcNow;
    }

    public void Deactivate()
    {
        IsActive = false;
    }
}