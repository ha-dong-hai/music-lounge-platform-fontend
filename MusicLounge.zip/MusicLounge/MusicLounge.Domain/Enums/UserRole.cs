﻿namespace MusicLounge.Domain.Enums;

public enum UserRole
{
    Admin = 1,
    Owner = 2,
    Staff = 3,
    Audience = 4
}