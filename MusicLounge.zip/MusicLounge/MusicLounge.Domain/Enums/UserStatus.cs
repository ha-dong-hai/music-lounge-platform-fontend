﻿namespace MusicLounge.Domain.Enums;

public enum UserStatus
{
    PendingVerification = 1,
    Active = 2,
    Rejected = 3,
    Suspended = 4
}