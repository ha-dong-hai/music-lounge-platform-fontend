﻿namespace MusicLounge.Domain.Enums;

public enum OwnerDocumentType
{
    BusinessLicense = 1,     // Giấy phép kinh doanh
    OwnerIdentity = 2,       // CCCD/CMND người đại diện
    LoungeImage = 3,         // Ảnh cơ sở/phòng trà
    Other = 4                // Giấy tờ khác
}