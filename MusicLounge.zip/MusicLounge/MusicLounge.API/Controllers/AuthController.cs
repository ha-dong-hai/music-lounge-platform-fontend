﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MusicLounge.Application.DTOs.Auth;
using MusicLounge.Application.Services;
using System.Security.Claims;

namespace MusicLounge.API.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly AuthService _authService;

    public AuthController(AuthService authService)
    {
        _authService = authService;
    }

    // PUBLIC API:
    // API này cho người dùng đăng ký tài khoản.
    // Không yêu cầu JWT token.
    // Mặc định nên đăng ký ra role Audience.
    [AllowAnonymous]
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        var userId = await _authService.RegisterAsync(request);

        return Ok(new
        {
            message = "Đăng ký thành công.",
            userId
        });
    }

    // PUBLIC API:
    // API này cho người dùng đăng nhập.
    // Nếu đăng nhập đúng, hệ thống trả về accessToken + role.
    // Frontend dùng role để điều hướng màn hình.
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var result = await _authService.LoginAsync(request);

        return Ok(result);
    }

    // PROTECTED API:
    // API này dùng để kiểm tra token sau khi đăng nhập.
    // Chỉ cần đăng nhập là gọi được, không phân biệt role.
    // Nếu chưa truyền Bearer token thì sẽ trả 401 Unauthorized.
    [Authorize]
    [HttpGet("me")]
    public IActionResult GetCurrentUser()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        var email = User.FindFirstValue(ClaimTypes.Email);
        var role = User.FindFirstValue(ClaimTypes.Role);

        return Ok(new
        {
            userId,
            email,
            role
        });
    }

    // TEST ROLE API:
    // API này chỉ Admin được gọi.
    // Dùng để test phân quyền role Admin.
    // Sai role sẽ trả 403 Forbidden.
    [Authorize(Roles = "Admin")]
    [HttpGet("test-admin")]
    public IActionResult TestAdmin()
    {
        return Ok("Bạn đang đăng nhập với quyền Admin.");
    }

    // TEST ROLE API:
    // API này chỉ Music Lounge Owner được gọi.
    // Trong code role đang lưu là Owner.
    // Sai role sẽ trả 403 Forbidden.
    [Authorize(Roles = "Owner")]
    [HttpGet("test-owner")]
    public IActionResult TestOwner()
    {
        return Ok("Bạn đang đăng nhập với quyền Music Lounge Owner.");
    }

    // TEST ROLE API:
    // API này chỉ Staff được gọi.
    [Authorize(Roles = "Staff")]
    [HttpGet("test-staff")]
    public IActionResult TestStaff()
    {
        return Ok("Bạn đang đăng nhập với quyền Staff.");
    }

    // TEST ROLE API:
    // API này chỉ Audience được gọi.
    [Authorize(Roles = "Audience")]
    [HttpGet("test-audience")]
    public IActionResult TestAudience()
    {
        return Ok("Bạn đang đăng nhập với quyền Audience.");
    }
}